export const addMoney = (amount) => {
    return (dispatch) => {
        dispatch({
            type: 'addMoney',
            payload: amount
        })
    }
}

export const minusMoney = (amount) => {
    return (dispatch) => {
        dispatch({
            type: 'minusMoney',
            payload: amount
        })
    }
}