import { configureStore } from '@reduxjs/toolkit';
import reducers from './reducers';
import { thunk } from 'redux-thunk'; // Correct way to import thunk (named import)

const store = configureStore({
  reducer: reducers,
  middleware: (getDefaultMiddleware) => getDefaultMiddleware().concat(thunk),  // Adding custom middleware if needed
});

export default store;
