import { combineReducers } from 'redux'; // Note the lowercase 'c' in combineReducers
import amountReducer from './amountReducer';

const reducers = combineReducers({
    amount: amountReducer
});

export default reducers;
