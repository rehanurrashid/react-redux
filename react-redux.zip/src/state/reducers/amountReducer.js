const amountReducer = (state = 0, action) => {
        console.log(action.payload)
    if (action.type === 'addMoney') {
        return state + action.payload;
    } else if (action.type === 'minusMoney') {
        return state - action.payload;
    } else {
        return state;
    }
};

export default amountReducer;
