import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { actionCreators } from '../state';  // Assuming this is where your action creators are
import { bindActionCreators } from 'redux';

const Shop = () => {
  const dispatch = useDispatch();
  const { addMoney, minusMoney} = bindActionCreators(actionCreators, dispatch);

  const handleAddMoney = (amount) => {
    addMoney(amount);
  };

  const handleMinusMoney = (amount) => {
    minusMoney(amount);
  };

  const amount = useSelector( state => state.amount)

  return (
    <div>
      <div className="row mt-3">
        <div className="col-3">
          <button
            className="btn btn-primary"
            onClick={() => handleAddMoney(10)} // Add 10 to the money
          >
            Add
          </button>
        </div>
        <div className="col-3">
          <button
            className="btn btn-warning"
            onClick={() => handleMinusMoney(10)} // Subtract 10 from the money
          >
            Subtract
          </button>
        </div>

        <div className="col-3">
          New balance: {amount}
        </div>

      </div>
    </div>
  );
};

export default Shop;
